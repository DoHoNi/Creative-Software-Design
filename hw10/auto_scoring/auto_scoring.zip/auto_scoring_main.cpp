

#include <iostream>
#include <string>
#include <stdlib.h>
#include <fstream>

using namespace std;

int main(int argc, const char ** argv)
{
    if(argc <=1 || argc>2) return -1;
    
    string pro_name = "./"+ string(argv[1])+"< ./" + string(argv[1]) +"_data/";
    string pro_out = ".in > out.out";
    
    int score=0;
    
    for(int i=1; i<=5; i++)
    {
        bool cor= true;
        
        string str1 = pro_name +char('0'+i)+pro_out;
        system(str1.c_str());
        
        ifstream you, ans;
        you.open("out.out");
        string str2 = "./"+string(argv[1])+"_data/"+char('0'+i)+".out";
        ans.open(str2.c_str());
        
        int j=0;
        string you_str, ans_str;
        while(1)
        {
            getline(you, you_str);
            getline(ans, ans_str);
            if(you.eof() || ans.eof()) break;
            if(you_str!=ans_str)
            {
                cout << "No." << i << ", LINE" << j << ": [" << you_str << "] MUST BE [" << ans_str << "]"  << endl;
                cor = false;
            }
            j++;
            
        }
        while(!ans.eof())
        {
            cout << "No." << i << ", LINE" << j << ": EMPTY MUST BE [" << ans_str << "]" <<endl;
            cor = false;
            getline(ans, ans_str);
        }
        while(!you.eof())
        {
            cout << "No." << i << ", LINE" << j << ": [" << you_str << "] MUST BE EMPTY" <<endl;
            cor = false;
            getline(you,you_str);
        }
        if(cor) score +=2;
        
    }
    cout << "SCORE:" << score <<endl;
    return 0;
}
